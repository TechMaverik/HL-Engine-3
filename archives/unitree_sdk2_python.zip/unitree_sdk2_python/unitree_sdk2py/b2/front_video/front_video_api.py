"""
" service name
"""
ROBOT_FRONT_VIDEO_SERVICE_NAME = "front_videohub"


"""
" service api version
"""
ROBOT_FRONT_VIDEO_API_VERSION = "1.0.0.0"


"""
" api id
"""
ROBOT_FRONT_VIDEO_API_ID_GETIMAGESAMPLE = 1001
