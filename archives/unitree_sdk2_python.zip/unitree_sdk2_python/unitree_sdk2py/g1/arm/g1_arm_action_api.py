"""
" service name
"""
ARM_ACTION_SERVICE_NAME = "arm"

"""
" service api version
"""
ARM_ACTION_API_VERSION = "1.0.0.14"

"""
" api id
"""
ROBOT_API_ID_ARM_ACTION_EXECUTE_ACTION = 7106
ROBOT_API_ID_ARM_ACTION_GET_ACTION_LIST = 7107

"""
" error code
"""