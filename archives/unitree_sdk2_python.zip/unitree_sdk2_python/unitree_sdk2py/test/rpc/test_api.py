# service name
TEST_SERVICE_NAME = "test"

# api version
TEST_API_VERSION = "1.0.0.1"

# api id
TEST_API_ID_MOVE = 1008
TEST_API_ID_STOP = 1002